
export async function get_tweets(){
  const tweets = await axios({
    method: 'get',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets',
    withCredentials: true,
  });

  let feed = document.createElement('div')
  tweets.data.slice(0,50).forEach((element )=> {
    feed.append(createTweet(element))
  });
  return feed
}

export function createTweet(tweetData){
  let tweet = document.createElement('div')
  tweet.className = 'tweet'
  tweet.setAttribute('tweetId', tweetData.id)

  let author = document.createElement('p')
  author.className = 'author'
  author.innerText = tweetData.author
  tweet.append(author)


  let inittext = ''
  if(tweetData.type == 'retweet'){
    if(tweetData.parent)
    inittext = '<p>retweet from: ' + tweetData.parent.author + '</p><p>' + tweetData.parent.body + '</p>'
  }
  if(tweetData.type == 'reply'){
    if(tweetData.parent)
    inittext = '<p>reply to: ' + tweetData.parent.author + '</p><p>' + tweetData.parent.body + '</p>'
  }

  let tweetBody = document.createElement('p')
  tweetBody.className = 'tweet-body'
  tweetBody.innerHTML = tweetData.body + inittext
  tweet.append(tweetBody)

  //control
  let control = document.createElement('div')
  control.className = 'control'
  control.setAttribute('tweetId', tweetData.id)
  tweet.append(control)

  let replyButton = document.createElement('button')
  replyButton.className = 'reply-button'
  replyButton.innerText = tweetData.replyCount + ' replies'
  control.append(replyButton)

  let retweetButton = document.createElement('button')
  retweetButton.className = 'retweet-button'
  retweetButton.innerText = tweetData.retweetCount + ' retweets'
  control.append(retweetButton)

  let likeButton = document.createElement('button')
  likeButton.className = 'like-button'
  likeButton.setAttribute('liked', tweetData.isLiked)
  likeButton.innerText = tweetData.likeCount + ' likes'
  if(tweetData.isLiked){
    likeButton.innerText = tweetData.likeCount + ' likes (You liked dis <3)'
  }
  control.append(likeButton)

  if(tweetData.isMine){
    likeButton.className = 'useless'
    let editButton = document.createElement('button')
    editButton.className = 'edit-button'
    editButton.innerText = 'edit'
    control.append(editButton)

    let delButton = document.createElement('button')
    delButton.className = 'del-button'
    delButton.innerText = 'delete'
    control.append(delButton)

  }

  return tweet

}

export function get_header(){
  let header = document.createElement('div')
  header.className = 'header'
  header.id = 'header'

  let tweetButton = document.createElement('button')
  tweetButton.className = 'tweet-button'
  tweetButton.innerText = 'Tweet Tweet mfs'

  header.append(tweetButton)
  return header
}

export function handleCancel(event){
  event.preventDefault()
  location.reload()
}

export async function handleSubmitRT(event){
  let id = event.target.parentNode.getAttribute('tweetId')

  let body = $('#'+ id).val()

  const result = await axios({
    method: 'post',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets',
    withCredentials: true,
    data: {
      "type": "retweet",
      "parent": id,
      "body": body
    },
  });

  location.reload()

}

export async function handleRetweet(event){
  event.preventDefault()
  let id = event.target.parentNode.getAttribute('tweetId')
  let tweet = event.target.parentNode;

  let form = $(tweet)

  tweet.innerHTML= ''


  let label = document.createElement('label')
  label.innerText = 'What you got to say?'
  tweet.append(label)
  
  let text = document.createElement('textarea')
  text.id = id
  text.maxLength = 280
  tweet.append(text)

  let retweetButton = document.createElement('button')
  retweetButton.innerText = 'retweet'
  retweetButton.className = 'submit-retweet'
  tweet.append(retweetButton)



  let cancelButton = document.createElement('button')
  cancelButton.innerText = 'cancel'
  cancelButton.className = 'cancel-button'
  tweet.append(cancelButton)

  form.on('click', '.submit-retweet', handleSubmitRT)
  form.on('click', '.cancel-button', handleCancel)

}

export async function handleSubmitReply(event){
  let id = event.target.parentNode.getAttribute('tweetId')

  let body = $('#'+ id).val()

  const result = await axios({
    method: 'post',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets',
    withCredentials: true,
    data: {
      "type": "reply",
      "parent": id,
      "body": body
    },
  });

  location.reload()

}

export async function handleReply(event){
  event.preventDefault()
  let id = event.target.parentNode.getAttribute('tweetId')
  let tweet = event.target.parentNode;

  let form = $(tweet)

  tweet.innerHTML= ''


  let label = document.createElement('label')
  label.innerText = 'What you got to say?'
  tweet.append(label)
  
  let text = document.createElement('textarea')
  text.id = id
  text.maxLength = 280
  tweet.append(text)

  let replyButton = document.createElement('button')
  replyButton.innerText = 'reply'
  replyButton.className = 'submit-reply'
  tweet.append(replyButton)



  let cancelButton = document.createElement('button')
  cancelButton.innerText = 'cancel'
  cancelButton.className = 'cancel-button'
  tweet.append(cancelButton)

  form.on('click', '.submit-reply', handleSubmitReply)
  form.on('click', '.cancel-button', handleCancel)

}


export async function handleEditSubmit(event){
  let id = event.target.parentNode.getAttribute('tweetId')

  let body = $('#'+ id).val()

  const result = await axios({
    method: 'put',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets/' + id,
    withCredentials: true,
    data: {
      body: body
    },
  });

  location.reload()

}
export async function handleEdit(event){
  event.preventDefault()
  let id = event.target.parentNode.getAttribute('tweetId')
  let tweet = event.target.parentNode;

  let form = $(tweet)

  tweet.innerHTML= ''


  let label = document.createElement('label')
  label.innerText = 'What you got to say?'
  tweet.append(label)
  
  let text = document.createElement('textarea')
  text.id = id
  text.maxLength = 280
  const ogtweet = await axios({
    method: 'get',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets/' + id,
    withCredentials: true,
  });
  text.value = ogtweet.data.body
  tweet.append(text)

  let editButton = document.createElement('button')
  editButton.innerText = 'edit'
  editButton.className = 'submit-edit'
  tweet.append(editButton)



  let cancelButton = document.createElement('button')
  cancelButton.innerText = 'cancel'
  cancelButton.className = 'cancel-button'
  tweet.append(cancelButton)

  form.on('click', '.submit-edit', handleEditSubmit)
  form.on('click', '.cancel-button', handleCancel)

}

export async function handleLike(event){
  event.preventDefault()
  let liked = event.target.getAttribute('liked')
  let id = event.target.parentNode.getAttribute('tweetId')

  if(liked == 'true'){
    const result = await axios({
      method: 'put',
      url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets/'+id+'/unlike',
      withCredentials: true,
    });
  }else{
    const result = await axios({
      method: 'put',
      url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets/'+id + '/like',
      withCredentials: true,
    });  
  }



    location.reload()
}

export async function handleDel(event){
  event.preventDefault()

  let id = event.target.parentNode.getAttribute('tweetId')


  const result = await axios({
    method: 'delete',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets/' + id,
    withCredentials: true,
  });

  location.reload()
}

export function handleTweet(event){
  event.preventDefault()
  let $header = $('#header')
  $header.empty()

  let form = document.createElement('form')
  $header.append(form)

  let label = document.createElement('label')
  label.innerText = 'What you got say?'
  form.append(label)
  
  let text = document.createElement('textarea')
  text.id = 'newtweet'
  text.maxLength = 280
  form.append(text)

  let tweetButton = document.createElement('button')
  tweetButton.className = 'submit-tweet'
  tweetButton.innerText = 'Tweet'
  form.append(tweetButton)

}

export async function handleSubmitTweet(event){
  event.preventDefault()
  let body = $('#newtweet').val()


  const result = await axios({
    method: 'post',
    url: 'https://comp426-1fa20.cs.unc.edu/a09/tweets',
    withCredentials: true,
    data: {
      body: body
    },
  });
  location.reload()
}

export async function loadIntoDOM(){
  let $root = $('#root')
  $root.empty()
  let feed  = await get_tweets()
  $root.append(get_header())
  $root.append(feed)

  $root.on('click', '.tweet-button', handleTweet)
  $root.on('click', '.submit-tweet', handleSubmitTweet)
  $root.on('click', '.like-button', handleLike)
  $root.on('click', '.retweet-button',handleRetweet)
  $root.on('click', '.reply-button',handleReply)
  $root.on('click', '.edit-button',handleEdit)
  $root.on('click', '.del-button',handleDel)

}
$(function(){
  loadIntoDOM()


})
